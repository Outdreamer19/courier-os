"""Word-synced burned-in captions (ASS) + SRT sidecar from the timeline JSON."""
import json, sys, re

B = '/home/claude/ad/build'


def ts(t):
    t = max(0, t); h = int(t // 3600); m = int(t % 3600 // 60); s = t % 60
    return f'{h}:{m:02d}:{s:05.2f}'


def srt_ts(t):
    t = max(0, t); ms = int(round(t * 1000)); h, ms = divmod(ms, 3600000); m, ms = divmod(ms, 60000); s, ms = divmod(ms, 1000)
    return f'{h:02d}:{m:02d}:{s:02d},{ms:03d}'


def chunks(words, maxc=20, maxw=4):
    out, cur = [], []
    for w in words:
        if cur and w['w'].startswith('“'):
            out.append(cur); cur = []
        cur.append(w)
        txt = ' '.join(x['w'] for x in cur)
        if len(cur) >= maxw or len(txt) >= maxc or re.search(r'[.,?!”]$', w['w']):
            out.append(cur); cur = []
    if cur: out.append(cur)
    # merge dangling single short words into previous chunk
    merged = []
    for c in out:
        if merged and len(c) == 1 and len(c[0]['w']) <= 4 and len(' '.join(x['w'] for x in merged[-1])) < 18:
            merged[-1] += c
        else:
            merged.append(c)
    return merged


HEAD = """[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,Inter,58,&H00F5FBFF,&H00F5FBFF,&H00020D21,&H00000000,-1,0,0,0,100,100,0,0,3,16,0,2,90,170,470,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""


def build(name):
    tl = json.load(open(f'{B}/{name}.json'))
    ev, srt = [], []
    n = 1
    for li, line in enumerate(tl['lines']):
        cs = chunks(line['words'])
        nxt_line = tl['lines'][li + 1]['start'] if li + 1 < len(tl['lines']) else tl['duration']
        for ci, c in enumerate(cs):
            start = c[0]['s'] - .06
            end = cs[ci + 1][0]['s'] - .06 if ci + 1 < len(cs) else min(line['end'] + .25, nxt_line - .08)
            srt.append(f"{n}\n{srt_ts(start)} --> {srt_ts(end)}\n{' '.join(w['w'] for w in c)}\n"); n += 1
            for wi, w in enumerate(c):
                ws = start if wi == 0 else w['s'] - .04
                we = (c[wi + 1]['s'] - .04) if wi + 1 < len(c) else end
                txt = ' '.join((r'{\c&H19D5FC&}' + x['w'] + r'{\c&HF5FBFF&}') if j == wi else x['w'] for j, x in enumerate(c))
                fade = r'{\fad(60,0)}' if wi == 0 else ''
                ev.append(f'Dialogue: 0,{ts(ws)},{ts(we)},Cap,,0,0,0,,{fade}{txt}')
    open(f'{B}/{name}.ass', 'w').write(HEAD + '\n'.join(ev) + '\n')
    open(f'{B}/{name}.srt', 'w').write('\n'.join(srt))
    print(name, len(srt), 'caption chunks')


for n in sys.argv[1:]:
    build(n)
