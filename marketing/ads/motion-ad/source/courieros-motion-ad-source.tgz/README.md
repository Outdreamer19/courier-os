# CourierOS motion ad: source

Rebuild pipeline for the Oct 2026 vertical ads (1080x1920, 30fps).

1. `python3 tighten.py vo2/<line>.wav vo2/c_<line>.wav 0.22`  trims pauses in each Higgsfield VO take
2. `python3 timeline.py [main cut15 hookB hookC hookD]`  stitches VO (rubberband tempo 1.07, cutdown 1.08), runs faster-whisper for word timings, writes build/<variant>.json and build/<variant>_vo.wav
3. `node render.mjs <variant> build/<variant>_video.mp4`  Playwright renders ad.html frame by frame (also writes build/<variant>_events.json for SFX)
4. `python3 audio.py <variant>`  original synth music + SFX, ducks under VO, loudnorm -14 LUFS / -1 dBTP
5. `python3 captions.py <variant>`  word-highlight ASS captions + SRT
6. `./mux.sh <variant> <OutputName>`  clean + captioned MP4 (H.264 High, AAC 320k)

Needs: node + playwright (chromium), ffmpeg with libass and rubberband, python3 numpy scipy faster-whisper.
Scenes, copy and timing live in ad.html (S1 hook, S2 brand, S3a customer, S3b owner, S4 outcome, S5 CTA).
UI images in assets/m are live captures of demo.courieros.co at 390x844 @3x.
Voice: Higgsfield seed_audio, preset Daisy (032386ec-491b-5bdc-81ac-49e9a6a2c89d), speech_rate 10, 48 kHz.
