// usage: node render.mjs <variant> <out.mp4> [--frames a,b,c --png dir]
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
import { spawn } from 'child_process'; import fs from 'fs';
const [,,name,out,...rest]=process.argv;
const tl=JSON.parse(fs.readFileSync(`build/${name}.json`,'utf8'));
const fi=rest.indexOf('--frames'); const only=fi>=0?rest[fi+1].split(',').map(Number):null;
const b=await chromium.launch({args:['--force-color-profile=srgb','--disable-lcd-text']});
const p=await b.newPage({viewport:{width:1080,height:1920},deviceScaleFactor:1});
await p.goto('file://'+process.cwd()+'/ad.html');
const info=await p.evaluate(async(tl)=>{const r=init(tl);await document.fonts.ready;await Promise.all([...document.images].map(i=>i.decode().catch(()=>{})));return r},tl);
fs.writeFileSync(`build/${name}_events.json`,JSON.stringify(info.events));
const FPS=30,N=Math.round(info.duration*FPS);
if(only){fs.mkdirSync(out,{recursive:true});
  for(const t of only){await p.evaluate(t=>seek(t),t);await p.screenshot({path:`${out}/${name}_${t.toFixed(2)}.jpg`,type:'jpeg',quality:85})}
  await b.close();process.exit(0)}
const ff=spawn('ffmpeg',['-y','-v','error','-f','image2pipe','-framerate',String(FPS),'-c:v','mjpeg','-i','-','-c:v','libx264','-preset','medium','-crf','14','-pix_fmt','yuv420p','-r',String(FPS),out],{stdio:['pipe','inherit','inherit']});
const t0=Date.now();
for(let i=0;i<N;i++){await p.evaluate(t=>seek(t),i/FPS);const buf=await p.screenshot({type:'jpeg',quality:96});
  if(!ff.stdin.write(buf))await new Promise(r=>ff.stdin.once('drain',r));
  if(i%150==0)console.log(name,i,'/',N,((Date.now()-t0)/1000).toFixed(0)+'s')}
ff.stdin.end();await new Promise(r=>ff.on('close',r));await b.close();console.log('done',out,((Date.now()-t0)/1000).toFixed(0)+'s');
