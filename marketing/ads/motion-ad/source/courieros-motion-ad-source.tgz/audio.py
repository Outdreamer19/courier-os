"""Original music bed + sound design + mix for each variant.
Everything here is synthesised from scratch (no samples), so the audio is fully owned.
usage: python3 audio.py <variant>
"""
import json, sys, wave, subprocess, numpy as np
from scipy import signal

SR = 48000
B = '/home/claude/ad/build'
rng = np.random.default_rng(11)


def load(f):
    raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', f, '-f', 'f32le', '-ac', '1', '-ar', str(SR), '-'], capture_output=True).stdout
    return np.frombuffer(raw, np.float32).astype(np.float64)


def save_st(f, L, R):
    a = np.stack([L, R], 1)
    a = np.clip(a, -1, 1)
    with wave.open(f, 'wb') as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes((a * 32767).astype(np.int16).tobytes())


def env(n, a, d, sus=0.0, r=None):
    t = np.arange(n) / SR
    e = np.minimum(1, t / max(a, 1e-4)) * (sus + (1 - sus) * np.exp(-np.maximum(0, t - a) / d))
    return e


def lp(x, fc, order=2):
    b, a = signal.butter(order, min(fc, SR / 2 - 100) / (SR / 2))
    return signal.lfilter(b, a, x)


def hp(x, fc, order=2):
    b, a = signal.butter(order, fc / (SR / 2), 'high')
    return signal.lfilter(b, a, x)


def bp(x, lo, hi, order=2):
    b, a = signal.butter(order, [lo / (SR / 2), hi / (SR / 2)], 'band')
    return signal.lfilter(b, a, x)


def sweep_lp(x, f0, f1):
    """time varying one-pole lowpass (cutoff glides f0->f1)."""
    n = len(x); fc = np.geomspace(f0, f1, n)
    g = 1 - np.exp(-2 * np.pi * fc / SR)
    y = np.zeros(n); s = 0.0
    for i in range(n):
        s += g[i] * (x[i] - s); y[i] = s
    return y


def saw(f, n, detune=0.0):
    t = np.arange(n) / SR
    out = np.zeros(n)
    for d in ([-detune, 0, detune] if detune else [0]):
        ph = (t * f * (1 + d)) % 1.0
        out += 2 * ph - 1
    return out / (3 if detune else 1)


def note(m):
    return 440 * 2 ** ((m - 69) / 12)


def add(buf, x, t, gain=1.0, pan=0.0):
    i = int(t * SR)
    if i >= buf.shape[1] or i + len(x) <= 0: return
    j0 = max(0, -i); i = max(0, i)
    x = x[j0:j0 + buf.shape[1] - i]
    l = np.cos((pan + 1) * np.pi / 4); r = np.sin((pan + 1) * np.pi / 4)
    buf[0, i:i + len(x)] += x * gain * l * 1.414
    buf[1, i:i + len(x)] += x * gain * r * 1.414


# ---------------- instruments ----------------
def kick():
    n = int(.5 * SR); t = np.arange(n) / SR
    f = 46 + 110 * np.exp(-t / .035)
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sin(ph) * np.exp(-t / .22)
    x += .3 * np.exp(-t / .004) * rng.standard_normal(n) * .3
    return np.tanh(x * 1.6) * .9


def clap():
    n = int(.35 * SR); t = np.arange(n) / SR
    no = rng.standard_normal(n)
    e = np.zeros(n)
    for o in (0, .011, .022):
        e += (t >= o) * np.exp(-np.maximum(0, t - o) / .012)
    e += (t >= .03) * np.exp(-np.maximum(0, t - .03) / .09) * .6
    return bp(no, 900, 4200) * e * .7


def hat(open_=False):
    n = int((.28 if open_ else .06) * SR); t = np.arange(n) / SR
    x = hp(rng.standard_normal(n), 7000, 3) * np.exp(-t / (.09 if open_ else .018))
    return x * .5


def pluck(m, dur=.32, bright=4200):
    n = int(dur * SR); t = np.arange(n) / SR
    x = saw(note(m), n, .004)
    x = lp(x * np.exp(-t / .16), bright)
    return x * np.minimum(1, t / .003)


def bassnote(m, dur):
    n = int(dur * SR); t = np.arange(n) / SR
    f = note(m)
    x = np.sin(2 * np.pi * f * t) + .35 * lp(saw(f, n), 600)
    e = np.minimum(1, t / .006) * np.exp(-t / (dur * .9)) * np.minimum(1, (dur - t) / .02).clip(0, 1)
    return np.tanh(x * e * 1.4) * .8


def pad(ms, dur, cutoff=1400):
    n = int(dur * SR); t = np.arange(n) / SR
    x = sum(saw(note(m), n, .006) for m in ms) / len(ms)
    x = lp(x, cutoff, 2)
    e = np.minimum(1, t / .5) * np.minimum(1, (dur - t) / .6).clip(0, 1)
    return x * e


def bell(m, dur=1.6):
    n = int(dur * SR); t = np.arange(n) / SR; f = note(m)
    x = (np.sin(2 * np.pi * f * t) * np.exp(-t / .7) + .5 * np.sin(2 * np.pi * f * 2.0 * t) * np.exp(-t / .35)
         + .25 * np.sin(2 * np.pi * f * 3.01 * t) * np.exp(-t / .2))
    return x * np.minimum(1, t / .002) * .5


# ---------------- sfx ----------------
def sfx(kind, i=0):
    if kind == 'pop':
        n = int(.12 * SR); t = np.arange(n) / SR
        f = (760 + 90 * (i % 3)) * (1 + .6 * np.exp(-t / .012))
        x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / .035)
        return x * .55
    if kind == 'tick':
        n = int(.03 * SR); t = np.arange(n) / SR
        return bp(rng.standard_normal(n), 1800, 6000) * np.exp(-t / .006) * .5
    if kind == 'blip':
        n = int(.25 * SR); t = np.arange(n) / SR
        return (np.sin(2 * np.pi * 1318 * t) + .4 * np.sin(2 * np.pi * 2636 * t)) * np.exp(-t / .07) * .28
    if kind in ('whoosh', 'swoosh', 'swipe'):
        d = {'whoosh': .55, 'swoosh': .34, 'swipe': .26}[kind]
        n = int(d * SR); t = np.arange(n) / SR
        x = rng.standard_normal(n)
        lo, hi = {'whoosh': (300, 5000), 'swoosh': (900, 7000), 'swipe': (2000, 9000)}[kind]
        y = sweep_lp(x, lo, hi) - sweep_lp(x, lo * .3, hi * .3) * .5
        e = np.sin(np.pi * np.clip(t / d, 0, 1)) ** 2
        return y * e * {'whoosh': .5, 'swoosh': .38, 'swipe': .3}[kind]
    if kind in ('impact', 'impact2'):
        n = int(1.4 * SR); t = np.arange(n) / SR
        f = 38 + 60 * np.exp(-t / .06)
        x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / .45)
        x += lp(rng.standard_normal(n), 3000) * np.exp(-t / .05) * .35
        if kind == 'impact2':
            x = x * .7 + hp(rng.standard_normal(n), 6000) * np.exp(-t / .5) * .05
        return np.tanh(x * 1.3) * .75
    if kind == 'riser2':
        d = 1.6; n = int(d * SR); t = np.arange(n) / SR
        y = sweep_lp(rng.standard_normal(n), 200, 6000)
        return y * (t / d) ** 2 * .35
    if kind == 'chime':
        a = bell(84, 1.8); a[:int(1.5*SR)] += .6 * bell(91, 1.5); return a
    return np.zeros(10)


# ---------------- arrangement ----------------
def build(name):
    tl = json.load(open(f'{B}/{name}.json'))
    ev = json.load(open(f'{B}/{name}_events.json'))
    dur = tl['duration']; N = int(dur * SR)
    lines = {l['id']: l for l in tl['lines']}
    first = tl['lines'][0]
    drop = (lines.get('L2') or lines['L3'])['start'] - .12
    cta = lines['L7b']['start'] - .28
    calm = lines['L6']['start'] - .22 if 'L6' in lines else None

    bpm = 112; beat = 60 / bpm
    mus = np.zeros((2, N + SR))
    # progression (C major, vi-IV-I-V): Am F C G, one chord per bar
    prog = [(57, [69, 72, 76]), (53, [65, 69, 72]), (48, [64, 67, 72]), (55, [62, 67, 71])]
    # bars relative to drop
    bar = 4 * beat
    nbars_pre = int(np.ceil(drop / bar)) + 1
    start_t = drop - nbars_pre * bar

    # pre-drop tension: filtered drone + ticking hats, riser into drop
    pre_n = int(max(drop, .1) * SR)
    dr = pad([45, 52, 57], drop + .3, 600) * .22
    dr = sweep_lp(dr, 300, 1600)
    add(mus, dr, 0, 1.0)
    pulse_t = np.arange(0, drop, beat / 2)
    for k, t in enumerate(pulse_t):
        add(mus, bassnote(33, beat * .4) * .35, t, .9)
        add(mus, hat(), t + beat / 4, .18 + .2 * (t / drop), pan=.3 if k % 2 else -.3)
    rs = sfx('riser2'); add(mus, rs, drop - len(rs) / SR, .6)

    # groove from drop to end
    t = drop; b = 0
    while t < dur + bar:
        ch = prog[b % 4]
        in_calm = calm is not None and calm <= t < cta
        is_end = t >= cta
        for q in range(4):
            tb = t + q * beat
            if tb >= dur: break
            if not in_calm or q in (0,):
                add(mus, kick(), tb, .85 if not in_calm else .5)
            if q in (1, 3) and not in_calm:
                add(mus, clap(), tb, .32, pan=.05)
            add(mus, hat(open_=True), tb + beat / 2, .16 if not in_calm else .08, pan=.2)
            for s in range(4):
                add(mus, hat(), tb + s * beat / 4, .07, pan=-.25)
            # bass 8ths (sidechain feel: off-beat louder)
            for e8 in range(2):
                add(mus, bassnote(ch[0] - 12, beat / 2 * .9), tb + e8 * beat / 2, .42 if e8 else .26)
        # arpeggio 16ths over chord
        arp = ch[1] + [ch[1][1] + 12]
        for s in range(16):
            ts = t + s * beat / 4
            if ts >= dur: break
            m = arp[[0, 1, 2, 3, 2, 1, 2, 3][s % 8]]
            add(mus, pluck(m, .28, 2600 + 1800 * (b % 2)), ts, .12 if not in_calm else .09, pan=-.35 if s % 2 else .35)
        add(mus, pad(ch[1], bar + .4, 1800 if not is_end else 2600), t, .16 if not in_calm else .22)
        t += bar; b += 1

    # CTA resolve: hold a C major chord over the last stretch
    res_t = max(cta + 2 * bar, dur - 3.0)
    tail = dur - res_t
    if tail > .5:
        mus[:, int(res_t * SR):] *= np.linspace(1, .25, mus.shape[1] - int(res_t * SR))
        add(mus, pad([60, 64, 67, 72], tail + .2, 2400), res_t, .3)
        add(mus, bell(72, 2.5), res_t, .25)
    # global fade in/out
    mus = mus[:, :N]
    mus[:, :int(.05 * SR)] *= np.linspace(0, 1, int(.05 * SR))
    fo = int(1.2 * SR); mus[:, -fo:] *= np.linspace(1, 0, fo) ** 1.5

    # ---- sfx track ----
    fx = np.zeros((2, N + SR))
    for e in ev:
        g = {'pop': .55, 'tick': .35, 'blip': .5, 'whoosh': .7, 'swoosh': .55, 'swipe': .5, 'impact': .9, 'impact2': .8, 'riser2': .6, 'chime': .55}.get(e['type'], .5)
        x = sfx(e['type'], e.get('i', 0))
        pan = (rng.random() - .5) * .4
        add(fx, x, max(0, e['t']), g, pan)
    fx = fx[:, :N]

    # ---- VO + ducking ----
    vo = load(f'{B}/{name}_vo.wav')[:N]
    vo = np.pad(vo, (0, N - len(vo)))
    vo = hp(vo, 80)
    # gentle presence + compression
    vo = vo + .25 * bp(vo, 2500, 6000)
    envv = lp(np.abs(vo), 20)
    pres = np.clip(envv / (np.percentile(envv[envv > 1e-4], 50) * .5 + 1e-9), 0, 1)
    # hold presence through short gaps between words
    k = int(.25 * SR); pres = np.maximum.accumulate(pres.reshape(-1)) if False else signal.convolve(pres, np.ones(k) / k, mode='same')
    pres = np.clip(pres * 3, 0, 1)
    duck = lp(1 - .6 * pres, 5)
    pre = int(drop * SR); mus[:, :pre] *= 3.0
    mus = mus * duck * .24
    mix = mus + fx * .5 + np.stack([vo, vo]) * 1.0
    return mix, mus, fx, vo


def finalize(name):
    mix, mus, fx, vo = build(name)
    out = f'{B}/{name}_mix_raw.wav'
    peak = np.abs(mix).max(); mix = mix / peak * .9
    save_st(out, mix[0], mix[1])
    # loudness normalise to -14 LUFS, TP -1.0
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', out, '-af', 'loudnorm=I=-14:TP=-1.0:LRA=9', '-ar', '48000', f'{B}/{name}_mix.wav'], check=True)
    # stems for the editor
    save_st(f'{B}/{name}_music_stem.wav', *(mus / max(1e-9, np.abs(mus).max()) * .8))
    save_st(f'{B}/{name}_sfx_stem.wav', *(fx / max(1e-9, np.abs(fx).max()) * .8))
    print(name, 'mixed')


if __name__ == '__main__':
    for n in sys.argv[1:]:
        finalize(n)
