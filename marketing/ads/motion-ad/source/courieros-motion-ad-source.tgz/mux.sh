#!/bin/bash
# mux.sh <variant> <outbase>
v=$1; o=$2
ffmpeg -v error -y -i build/${v}_video.mp4 -i build/${v}_mix.wav -map 0:v -map 1:a -c:v libx264 -preset slow -crf 16 -profile:v high -pix_fmt yuv420p -r 30 -c:a aac -b:a 320k -ar 48000 -movflags +faststart -shortest out/${o}_clean.mp4
ffmpeg -v error -y -i build/${v}_video.mp4 -i build/${v}_mix.wav -map 0:v -map 1:a -vf "ass=build/${v}.ass:fontsdir=fonts" -c:v libx264 -preset slow -crf 16 -profile:v high -pix_fmt yuv420p -r 30 -c:a aac -b:a 320k -ar 48000 -movflags +faststart -shortest out/${o}.mp4
echo muxed $o
