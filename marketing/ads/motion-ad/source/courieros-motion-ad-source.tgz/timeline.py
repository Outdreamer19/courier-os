import json, subprocess, numpy as np, wave, re, sys, os
VO='/home/claude/ad/vo2'; OUT='/home/claude/ad/build'
SR=48000
TEXT={
 'L1':'Still answering “did my package reach?” all day?',
 'L2':'Meet CourierOS. Your own branded courier website and customer portal.',
 'L2a':'Meet CourierOS.',
 'L3':'Customers get their own Miami address, send pre-alerts, and track every package themselves.',
 'L4':'And you see every parcel, from Miami to pickup, in one dashboard.',
 'L6':'Your brand. Your customers. Without the chaos.',
 'L7b':'Try the live demo at courieros.co',
 'H9':'Still running your courier business on WhatsApp and a spreadsheet?',
 'H10':'Always wanted your own shipping business? Here’s the software behind it.',
 'H11':'“How much for six pounds?” Let your website answer that.',
}
CUT={'L2a':('L2',0,1.45),'L7b':('L7',1.15,None)}
def load(f):
    raw=subprocess.run(['ffmpeg','-v','error','-i',f,'-f','f32le','-ac','1','-ar',str(SR),'-'],capture_output=True).stdout
    return np.frombuffer(raw,np.float32).copy()
def save(f,a):
    b=(np.clip(a,-1,1)*32767).astype(np.int16)
    with wave.open(f,'wb') as w: w.setnchannels(1);w.setsampwidth(2);w.setframerate(SR);w.writeframes(b.tobytes())
def clip(id,tempo):
    p=f'{OUT}/p_{id}_{tempo}.wav'
    if not os.path.exists(p):
        src,s,e=CUT.get(id,(id,0,None))
        a=load(f'{VO}/c_{src}.wav'); a=a[int(s*SR):(int(e*SR) if e else None)]
        f=int(.012*SR); a[:f]*=np.linspace(0,1,f); a[-f:]*=np.linspace(1,0,f)
        save(p+'.tmp.wav',a)
        subprocess.run(['ffmpeg','-v','error','-y','-i',p+'.tmp.wav','-af',f'rubberband=tempo={tempo}:pitchq=quality','-ar',str(SR),p],check=True)
        os.remove(p+'.tmp.wav')
    return p
_m=None
def words(path,id):
    global _m
    from faster_whisper import WhisperModel
    if _m is None: _m=WhisperModel('base.en',device='cpu',compute_type='int8')
    a=load(path); a16=a[::3].astype(np.float32)
    segs,_=_m.transcribe(a16,word_timestamps=True)
    ww=[(w.word,w.start,w.end) for s in segs for w in s.words]
    norm=lambda s: re.sub(r'[^a-z0-9]','',s.lower())
    # char positions for whisper
    wpos=[];c=0
    for w,s,e in ww:
        n=len(norm(w)); wpos.append((c,c+n,s,e)); c+=n
    canon=TEXT[id].split(); out=[];c=0
    for cw in canon:
        n=len(norm(cw)); a0,a1=c,c+max(n,1); c+=n
        hits=[x for x in wpos if x[1]>a0 and x[0]<a1] or [wpos[-1]]
        out.append({'w':cw,'s':round(hits[0][2],3),'e':round(hits[-1][3],3)})
    return out, ' '.join(norm(w) for w,_,_ in ww)
def build(name,seq,tempo,hold=3.3,fixed=None):
    t=0.15; lines=[]; track=[]
    for i,(id,gap) in enumerate(seq):
        if i: t+=gap
        p=clip(id,tempo); a=load(p); d=len(a)/SR
        wd,heard=words(p,id)
        lines.append({'id':id,'text':TEXT[id],'start':round(t,3),'end':round(t+d,3),'words':[{**x,'s':round(x['s']+t,3),'e':round(x['e']+t,3)} for x in wd],'heard':heard})
        track.append((t,a)); t+=d
    total=fixed or round(min(30.0,t+hold)*30)/30
    vo=np.zeros(int(total*SR)+SR)
    for st,a in track: i=int(st*SR); vo[i:i+len(a)]+=a
    vo=vo[:int(total*SR)]
    save(f'{OUT}/{name}_vo.wav',vo)
    json.dump({'name':name,'duration':total,'lines':lines},open(f'{OUT}/{name}.json','w'),indent=1)
    print(name,'total',total,'vo end',round(t,2)); [print('  ',l['id'],l['start'],l['end'],'|',l['heard']) for l in lines]
V={
 'main':([('L1',0),('L2',.2),('L3',.25),('L4',.2),('L6',.4),('L7b',.5)],1.07),
 'cut15':([('L1',0),('L3',.25),('L7b',.4)],1.08),
 'hookB':([('H9',0),('L2',.2),('L3',.25),('L4',.2),('L6',.4),('L7b',.5)],1.07),
 'hookC':([('H10',0),('L2',.2),('L3',.25),('L4',.2),('L6',.4),('L7b',.5)],1.07),
 'hookD':([('H11',0),('L2',.2),('L3',.25),('L4',.2),('L6',.4),('L7b',.5)],1.07),
}
for n in (sys.argv[1:] or V):
    seq,tempo=V[n]
    build(n,seq,tempo, fixed=15.0 if n=='cut15' else None)
