# Compress internal pauses longer than MAXGAP down to MAXGAP; trim ends. Output 48k mono wav.
import sys, subprocess, numpy as np, wave
def load(f):
    raw=subprocess.run(['ffmpeg','-v','error','-i',f,'-f','f32le','-ac','1','-ar','48000','-'],capture_output=True).stdout
    return np.frombuffer(raw,np.float32).copy()
def save(f,a):
    a=np.clip(a,-1,1); b=(a*32767).astype(np.int16)
    with wave.open(f,'wb') as w: w.setnchannels(1);w.setsampwidth(2);w.setframerate(48000);w.writeframes(b.tobytes())
src,dst=sys.argv[1],sys.argv[2]; maxgap=float(sys.argv[3]) if len(sys.argv)>3 else 0.22
a=load(src); sr=48000; hop=480
rms=np.array([np.sqrt(np.mean(a[i:i+hop]**2)+1e-12) for i in range(0,len(a),hop)])
db=20*np.log10(rms); thr=db.max()-38
voiced=db>thr
idx=np.where(voiced)[0]; s,e=idx[0],idx[-1]
pad=4 # 40ms
out=[];i=max(0,s-pad)
segs=[];cur=None
# find silence runs between s and e
k=s
keep=np.ones(len(voiced),bool); keep[:max(0,s-pad)]=False; keep[min(len(voiced),e+pad+6):]=False
run=0
for j in range(s,e+1):
    if not voiced[j]: run+=1
    else:
        if run*hop/sr>maxgap:
            n_keep=int(maxgap*sr/hop); start=j-run
            # keep head and tail of the gap, drop middle
            keep[start+n_keep//2:j-(n_keep-n_keep//2)]=False
        run=0
pieces=[a[f*hop:(f+1)*hop] for f in range(len(voiced)) if keep[f]]
o=np.concatenate(pieces)
# tiny fades
f=int(0.01*sr); o[:f]*=np.linspace(0,1,f); o[-f:]*=np.linspace(1,0,f)
save(dst,o); print(dst, round(len(a)/sr,2),'->',round(len(o)/sr,2))
